﻿using System;

namespace AccountsCodingTest.Models
{
    /// Model of single account as retrieved from web service
    public class Account
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        //[DisplayFormat(DataFormatString = "@{0:(###)-###-####}")]
        public string PhoneNumber { get; set; }
        public decimal AmountDue { get; set; }
        public DateTimeOffset? PaymentDueDate { get; set; }
        public AccountStatuses AccountStatusId { get; set; }
    }
}
