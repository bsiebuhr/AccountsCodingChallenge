using System.Collections.Generic;

namespace AccountsCodingTest.Models
{
    /// Model of accounts grouped / sorted into three status
    public class AccountsByStatus
    {
        public List<Account> ActiveAccounts {get;set;}
        public List<Account> InactiveAccounts {get;set;}
        public List<Account> OverdueAcounts {get;set;}
        public AccountsByStatus()
        {
                ActiveAccounts = new List<Account>();
                InactiveAccounts = new List<Account>();
                OverdueAcounts = new List<Account>();
        }
    }
}

