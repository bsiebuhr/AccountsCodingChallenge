﻿namespace AccountsCodingTest.Models
{
    public enum AccountStatuses
    {
        Active,
        Inactive,
        Overdue,
    }
}
