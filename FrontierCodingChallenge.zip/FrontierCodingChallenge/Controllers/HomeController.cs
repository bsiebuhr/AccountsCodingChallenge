﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using AccountsCodingTest.Models;
using AccountsCodingTest.Factories;

namespace AccountsCodingTest.Controllers
{
    public class HomeController : Controller
    {
        ///private readonly ILogger<HomeController> _logger;

        ///public HomeController(ILogger<HomeController> logger)
        ///{
        ///    _logger = logger;
        ///}

        public IActionResult Index()
        {
            // Populate list of account objects
            IEnumerable<Account> allAccounts = AccountsMockDataFactory.CreateAccountsCollection();

            // Separate by Account Status
            Models.AccountsByStatus accountsByStatus = new AccountsByStatus();
            foreach (Account thisAcct in allAccounts)
            {
                if (thisAcct.AccountStatusId == AccountStatuses.Active)
                {
                    accountsByStatus.ActiveAccounts.Add(thisAcct);
                }
               if (thisAcct.AccountStatusId == AccountStatuses.Inactive)
                {
                    accountsByStatus.InactiveAccounts.Add(thisAcct);
                }
               if (thisAcct.AccountStatusId == AccountStatuses.Overdue)
                {
                    accountsByStatus.OverdueAcounts.Add(thisAcct);
                }
            }
            //TODO: sort accounts by name
            //Display the results
            return View("ViewAccountStatus", accountsByStatus);
        }

        
        /// TODO: Build view for handling errors
        ///public IActionResult Error()
        ///{
        /// return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        ///}
    }
}
